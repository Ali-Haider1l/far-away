import React from "react";

export default function FarAwayApp() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-800 via-indigo-900 to-black text-white">
      <div className="w-full max-w-md p-6 rounded-2xl shadow-xl border border-indigo-700 bg-indigo-950/50 backdrop-blur-md">
        <div className="flex flex-col gap-4 text-center">
          <h1 className="text-3xl font-bold text-indigo-200">Far Away</h1>
          <p className="text-base text-indigo-300">
            A Farcaster mini app by Ali Haidar
          </p>
          <p className="text-sm text-indigo-400">
            Launching July 14, 2025. Explore experimental decentralized interaction within the Farcaster ecosystem.
          </p>
          <button className="mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-full">
            ✨ Explore Far Away
          </button>
        </div>
      </div>
    </div>
  );
}