import React from "react";
import ReactDOM from "react-dom/client";
import FarAwayApp from "./FarAwayApp";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FarAwayApp />
  </React.StrictMode>
);